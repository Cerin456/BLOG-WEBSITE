'use client';

import Link from 'next/link';
import { useState } from 'react';

interface BlogCardProps {
  id: string;
  title: string;
  excerpt: string;
  author: string;
  publishDate: string;
  readTime: string;
  likes: number;
  comments: number;
  tags: string[];
  image?: string;
}

export default function BlogCard({ 
  id, 
  title, 
  excerpt, 
  author, 
  publishDate, 
  readTime, 
  likes, 
  comments, 
  tags, 
  image 
}: BlogCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 overflow-hidden">
      {image && (
        <div className="h-48 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
              {author.charAt(0)}
            </div>
            <span className="text-sm text-gray-600">{author}</span>
          </div>
          <span className="text-xs text-gray-500">{publishDate}</span>
        </div>

        <Link href={`/blog/${id}`} className="cursor-pointer">
          <h3 className="text-xl font-bold text-gray-900 mb-2 hover:text-blue-600 transition-colors line-clamp-2">
            {title}
          </h3>
          <p className="text-gray-600 mb-4 line-clamp-3">{excerpt}</p>
        </Link>

        <div className="flex flex-wrap gap-2 mb-4">
          {tags.map((tag, index) => (
            <span
              key={index}
              className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={handleLike}
              className={`flex items-center space-x-1 cursor-pointer transition-colors ${
                isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
              }`}
            >
              <i className={`w-4 h-4 flex items-center justify-center ${
                isLiked ? 'ri-heart-fill' : 'ri-heart-line'
              }`}></i>
              <span className="text-sm">{likeCount}</span>
            </button>
            
            <div className="flex items-center space-x-1 text-gray-500">
              <i className="ri-chat-1-line w-4 h-4 flex items-center justify-center"></i>
              <span className="text-sm">{comments}</span>
            </div>
            
            <div className="flex items-center space-x-1 text-gray-500">
              <i className="ri-time-line w-4 h-4 flex items-center justify-center"></i>
              <span className="text-sm">{readTime}</span>
            </div>
          </div>
          
          <button className="text-gray-500 hover:text-blue-600 transition-colors cursor-pointer">
            <i className="ri-bookmark-line w-4 h-4 flex items-center justify-center"></i>
          </button>
        </div>
      </div>
    </div>
  );
}