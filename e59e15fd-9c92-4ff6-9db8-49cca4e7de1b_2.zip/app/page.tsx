
'use client';

import Header from '@/components/Header';
import BlogCard from '@/components/BlogCard';
import { useState, useEffect } from 'react';

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredBlogs, setFilteredBlogs] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const featuredBlogs = [
    {
      id: '1',
      title: 'The Future of Web Development: What to Expect in 2024',
      excerpt: 'Explore the latest trends and technologies shaping the web development landscape. From AI-powered tools to new JavaScript frameworks, discover what developers need to know.',
      author: 'Sarah Johnson',
      publishDate: '2 hours ago',
      readTime: '8 min read',
      likes: 142,
      comments: 23,
      tags: ['Web Development', 'JavaScript', 'AI', 'Technology'],
      image: 'https://readdy.ai/api/search-image?query=modern%20web%20development%20workspace%20with%20multiple%20monitors%20showing%20code%2C%20futuristic%20tech%20setup%2C%20clean%20minimal%20background%2C%20professional%20lighting%2C%20high-tech%20atmosphere%2C%20coding%20environment&width=400&height=250&seq=1&orientation=landscape'
    },
    {
      id: '2',
      title: 'Building Better User Experiences: A Designer\'s Guide',
      excerpt: 'Learn how to create intuitive and engaging user interfaces that keep users coming back. This comprehensive guide covers everything from user research to prototyping.',
      author: 'Michael Chen',
      publishDate: '5 hours ago',
      readTime: '12 min read',
      likes: 89,
      comments: 15,
      tags: ['UX Design', 'UI Design', 'User Research', 'Prototyping'],
      image: 'https://readdy.ai/api/search-image?query=user%20experience%20design%20process%20with%20wireframes%20and%20mockups%2C%20clean%20workspace%20with%20design%20tools%2C%20modern%20office%20environment%2C%20creative%20atmosphere%2C%20professional%20setup&width=400&height=250&seq=2&orientation=landscape'
    },
    {
      id: '3',
      title: 'The Rise of Artificial Intelligence in Content Creation',
      excerpt: 'How AI is transforming the way we create and consume content. From automated writing to personalized recommendations, explore the impact of AI on modern content creation.',
      author: 'Emma Rodriguez',
      publishDate: '1 day ago',
      readTime: '6 min read',
      likes: 256,
      comments: 45,
      tags: ['AI', 'Content Creation', 'Machine Learning', 'Technology'],
      image: 'https://readdy.ai/api/search-image?query=artificial%20intelligence%20and%20content%20creation%20concept%2C%20robot%20writing%20with%20pen%2C%20futuristic%20digital%20workspace%2C%20blue%20and%20purple%20lighting%2C%20technology%20background&width=400&height=250&seq=3&orientation=landscape'
    },
    {
      id: '4',
      title: 'Remote Work Revolution: Tips for Digital Nomads',
      excerpt: 'Master the art of working from anywhere with these practical tips and strategies. Learn how to stay productive, maintain work-life balance, and build a successful remote career.',
      author: 'David Kim',
      publishDate: '2 days ago',
      readTime: '10 min read',
      likes: 178,
      comments: 32,
      tags: ['Remote Work', 'Digital Nomad', 'Productivity', 'Lifestyle'],
      image: 'https://readdy.ai/api/search-image?query=digital%20nomad%20working%20on%20laptop%20in%20beautiful%20tropical%20location%2C%20beach%20or%20mountain%20view%2C%20modern%20workspace%20setup%2C%20natural%20lighting%2C%20inspirational%20travel%20work%20environment&width=400&height=250&seq=4&orientation=landscape'
    },
    {
      id: '5',
      title: 'Sustainable Living: Small Changes, Big Impact',
      excerpt: 'Discover simple yet effective ways to reduce your environmental footprint. From eco-friendly products to sustainable habits, learn how to make a positive difference.',
      author: 'Lisa Thompson',
      publishDate: '3 days ago',
      readTime: '7 min read',
      likes: 201,
      comments: 28,
      tags: ['Sustainability', 'Environment', 'Green Living', 'Lifestyle'],
      image: 'https://readdy.ai/api/search-image?query=sustainable%20living%20concept%20with%20eco-friendly%20products%2C%20green%20plants%2C%20reusable%20items%2C%20natural%20materials%2C%20clean%20minimalist%20background%2C%20environmental%20consciousness&width=400&height=250&seq=5&orientation=landscape'
    },
    {
      id: '6',
      title: 'The Science of Habit Formation: Building Better Routines',
      excerpt: 'Understand the psychology behind habit formation and learn evidence-based strategies to build positive routines that stick. Transform your daily life with scientific insights.',
      author: 'Dr. James Wilson',
      publishDate: '4 days ago',
      readTime: '9 min read',
      likes: 134,
      comments: 19,
      tags: ['Psychology', 'Habits', 'Self-Improvement', 'Science'],
      image: 'https://readdy.ai/api/search-image?query=habit%20formation%20concept%20with%20calendar%2C%20checkmarks%2C%20daily%20routine%20items%2C%20organized%20workspace%2C%20motivational%20setup%2C%20clean%20background%2C%20productivity%20focused&width=400&height=250&seq=6&orientation=landscape'
    },
    {
      id: '7',
      title: 'Mastering JavaScript: Advanced Tips and Tricks',
      excerpt: 'Take your JavaScript skills to the next level with these advanced techniques and best practices. From closures to async/await, master the language that powers the web.',
      author: 'Alex Thompson',
      publishDate: '5 days ago',
      readTime: '11 min read',
      likes: 167,
      comments: 24,
      tags: ['JavaScript', 'Programming', 'Web Development', 'Tutorial'],
      image: 'https://readdy.ai/api/search-image?query=javascript%20programming%20concept%20with%20code%20on%20screen%2C%20modern%20development%20environment%2C%20clean%20workspace%2C%20coding%20symbols%2C%20professional%20tech%20setup&width=400&height=250&seq=7&orientation=landscape'
    },
    {
      id: '8',
      title: 'The Art of Photography: Capturing Perfect Moments',
      excerpt: 'Discover the secrets behind stunning photography. Learn composition techniques, lighting tips, and post-processing methods that will elevate your photography skills.',
      author: 'Maria Garcia',
      publishDate: '6 days ago',
      readTime: '8 min read',
      likes: 203,
      comments: 31,
      tags: ['Photography', 'Art', 'Visual Arts', 'Tutorial'],
      image: 'https://readdy.ai/api/search-image?query=professional%20photography%20setup%20with%20camera%2C%20lenses%2C%20lighting%20equipment%2C%20artistic%20composition%2C%20creative%20workspace%2C%20photographer%20tools&width=400&height=250&seq=8&orientation=landscape'
    },
    {
      id: '9',
      title: 'Entrepreneurship in the Digital Age: Building Your Startup',
      excerpt: 'Navigate the challenges of starting a business in today\'s digital landscape. From idea validation to funding, learn what it takes to build a successful startup.',
      author: 'Robert Chen',
      publishDate: '1 week ago',
      readTime: '15 min read',
      likes: 289,
      comments: 52,
      tags: ['Entrepreneurship', 'Startup', 'Business', 'Digital'],
      image: 'https://readdy.ai/api/search-image?query=startup%20business%20environment%20with%20modern%20office%2C%20entrepreneurs%20working%2C%20digital%20devices%2C%20innovative%20atmosphere%2C%20professional%20business%20setting&width=400&height=250&seq=9&orientation=landscape'
    }
  ];

  useEffect(() => {
    if (searchQuery.trim()) {
      setIsSearching(true);
      const filtered = featuredBlogs.filter(blog =>
        blog.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        blog.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        blog.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        blog.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      setFilteredBlogs(filtered);
    } else {
      setIsSearching(false);
      setFilteredBlogs([]);
    }
  }, [searchQuery]);

  const blogsToShow = isSearching ? filteredBlogs : featuredBlogs;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onSearch={setSearchQuery} />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        {isSearching ? (
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Search Results for "{searchQuery}"
            </h1>
            <p className="text-gray-600">
              {filteredBlogs.length} {filteredBlogs.length === 1 ? 'result' : 'results'} found
            </p>
          </div>
        ) : (
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Featured Stories</h1>
            <p className="text-gray-600">Discover the latest insights and stories from our community</p>
          </div>
        )}

        {blogsToShow.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogsToShow.map((blog) => (
              <BlogCard key={blog.id} {...blog} />
            ))}
          </div>
        ) : isSearching ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <i className="ri-search-line text-gray-400 w-8 h-8 flex items-center justify-center"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No results found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search terms or browse our featured stories</p>
            <button 
              onClick={() => setSearchQuery('')}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer"
            >
              Clear Search
            </button>
          </div>
        ) : null}

        {!isSearching && (
          <div className="mt-12">
            <div className="bg-white rounded-lg shadow-sm border p-8 text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Start Your Writing Journey</h2>
              <p className="text-gray-600 mb-6">Join thousands of writers sharing their stories and connecting with readers worldwide</p>
              <a href="/write" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer inline-block">
                Write Your First Blog
              </a>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
