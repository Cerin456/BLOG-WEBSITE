'use client';

import Header from '@/components/Header';
import { useState } from 'react';

export default function WritePage() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [category, setCategory] = useState('');
  const [isPublished, setIsPublished] = useState(false);

  const categories = [
    'Technology',
    'Design',
    'Business',
    'Lifestyle',
    'Science',
    'Health',
    'Travel',
    'Food',
    'Education',
    'Entertainment'
  ];

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim()) && tags.length < 5) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleSubmit = () => {
    if (!title.trim() || !content.trim() || !category) {
      alert('Please fill in all required fields');
      return;
    }
    
    setIsPublished(true);
    setTimeout(() => {
      alert('Blog published successfully!');
      setTitle('');
      setContent('');
      setTags([]);
      setCategory('');
      setIsPublished(false);
    }, 2000);
  };

  const handleSaveDraft = () => {
    alert('Draft saved successfully!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-6 py-8">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Write Your Story</h1>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter an engaging title for your blog post..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                maxLength={100}
              />
              <p className="text-sm text-gray-500 mt-1">{title.length}/100</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 pr-8"
              >
                <option value="">Select a category</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tags (max 5)
              </label>
              <div className="flex flex-wrap gap-2 mb-3">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center gap-1"
                  >
                    {tag}
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="w-4 h-4 flex items-center justify-center cursor-pointer"
                    >
                      <i className="ri-close-line w-3 h-3 flex items-center justify-center"></i>
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                  placeholder="Add a tag..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  disabled={tags.length >= 5}
                />
                <button
                  onClick={handleAddTag}
                  disabled={!tagInput.trim() || tags.length >= 5}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
                >
                  Add Tag
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Content *
              </label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Tell your story... Use markdown for formatting or write in plain text."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={16}
                maxLength={10000}
              />
              <p className="text-sm text-gray-500 mt-1">{content.length}/10,000</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Writing Tips</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Start with a compelling hook to grab readers' attention</li>
                <li>• Use clear, concise language and short paragraphs</li>
                <li>• Include relevant examples and personal experiences</li>
                <li>• End with a strong conclusion or call-to-action</li>
              </ul>
            </div>

            <div className="flex items-center justify-between pt-6 border-t">
              <button
                onClick={handleSaveDraft}
                className="text-gray-600 hover:text-gray-800 transition-colors cursor-pointer"
              >
                Save as Draft
              </button>
              
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleSubmit}
                  disabled={isPublished || !title.trim() || !content.trim() || !category}
                  className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors whitespace-nowrap cursor-pointer"
                >
                  {isPublished ? 'Publishing...' : 'Publish Blog'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}