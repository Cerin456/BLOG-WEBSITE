'use client';

import Header from '@/components/Header';
import CommentSection from '@/components/CommentSection';
import { useState } from 'react';

interface BlogDetailProps {
  blogId: string;
}

export default function BlogDetail({ blogId }: BlogDetailProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(142);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  const blog = {
    id: blogId,
    title: 'The Future of Web Development: What to Expect in 2024',
    content: `
      <p>The web development landscape is constantly evolving, and 2024 promises to be a year of significant transformation. As developers, staying ahead of the curve is crucial for building modern, efficient, and user-friendly applications.</p>
      
      <h2>Emerging Technologies</h2>
      <p>Artificial Intelligence is becoming increasingly integrated into development workflows. AI-powered tools are revolutionizing how we write code, debug applications, and optimize performance. From intelligent code completion to automated testing, these tools are making developers more productive than ever.</p>
      
      <p>WebAssembly (WASM) is gaining momentum as a game-changing technology that allows developers to run high-performance applications directly in the browser. This opens up new possibilities for complex applications that were previously limited to native development.</p>
      
      <h2>Framework Evolution</h2>
      <p>React continues to evolve with new features like Server Components and Suspense, making it easier to build performant applications. Vue.js and Angular are also introducing innovative features that enhance developer experience and application performance.</p>
      
      <p>The rise of meta-frameworks like Next.js, Nuxt.js, and SvelteKit demonstrates the industry's move toward full-stack solutions that provide built-in optimizations and developer conveniences.</p>
      
      <h2>Performance and Accessibility</h2>
      <p>Core Web Vitals have become essential metrics for web performance. Developers are increasingly focused on creating applications that not only function well but also provide excellent user experiences across all devices and connection speeds.</p>
      
      <p>Accessibility is no longer an afterthought but a fundamental requirement. Modern development practices emphasize building inclusive applications that work for users with disabilities.</p>
      
      <h2>The Future is Bright</h2>
      <p>As we look ahead, the web development community continues to push boundaries and create innovative solutions. The combination of powerful tools, improved frameworks, and a focus on user experience positions us for an exciting future in web development.</p>
    `,
    author: 'Sarah Johnson',
    publishDate: '2 hours ago',
    readTime: '8 min read',
    tags: ['Web Development', 'JavaScript', 'AI', 'Technology'],
    image: 'https://readdy.ai/api/search-image?query=modern%20web%20development%20workspace%20with%20multiple%20monitors%20showing%20code%2C%20futuristic%20tech%20setup%2C%20clean%20minimal%20background%2C%20professional%20lighting%2C%20high-tech%20atmosphere%2C%20coding%20environment&width=800&height=400&seq=1&orientation=landscape'
  };

  const comments = [
    {
      id: '1',
      author: 'Alex Martinez',
      content: 'Great article! I\'m particularly excited about the WebAssembly developments. It\'s going to change how we think about web performance.',
      date: '1 hour ago',
      likes: 12,
      replies: [
        {
          id: '1-1',
          author: 'Sarah Johnson',
          content: 'Thanks Alex! WebAssembly is definitely one of the most exciting developments in web tech right now.',
          date: '45 minutes ago',
          likes: 3,
          replies: []
        }
      ]
    },
    {
      id: '2',
      author: 'Jennifer Lee',
      content: 'The section on AI-powered tools resonates with me. I\'ve been using GitHub Copilot and it\'s incredible how much it speeds up development.',
      date: '2 hours ago',
      likes: 8,
      replies: []
    },
    {
      id: '3',
      author: 'Robert Brown',
      content: 'Accessibility focus is so important. Too many developers still treat it as optional when it should be fundamental.',
      date: '3 hours ago',
      likes: 15,
      replies: []
    }
  ];

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-4xl mx-auto px-6 py-8">
        <article className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="h-64 overflow-hidden">
            <img
              src={blog.image}
              alt={blog.title}
              className="w-full h-full object-cover object-top"
            />
          </div>
          
          <div className="p-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">
                  {blog.author.charAt(0)}
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{blog.author}</h3>
                  <p className="text-sm text-gray-500">{blog.publishDate} • {blog.readTime}</p>
                </div>
              </div>
              
              <button
                onClick={handleFollow}
                className={`px-4 py-2 rounded-lg whitespace-nowrap cursor-pointer transition-colors ${
                  isFollowing
                    ? 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {isFollowing ? 'Following' : 'Follow'}
              </button>
            </div>

            <h1 className="text-3xl font-bold text-gray-900 mb-4">{blog.title}</h1>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {blog.tags.map((tag, index) => (
                <span
                  key={index}
                  className="bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
            
            <div className="prose prose-lg max-w-none mb-8">
              <div dangerouslySetInnerHTML={{ __html: blog.content }} />
            </div>
            
            <div className="flex items-center justify-between py-4 border-t border-gray-200">
              <div className="flex items-center space-x-6">
                <button
                  onClick={handleLike}
                  className={`flex items-center space-x-2 cursor-pointer transition-colors ${
                    isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                  }`}
                >
                  <i className={`w-5 h-5 flex items-center justify-center ${
                    isLiked ? 'ri-heart-fill' : 'ri-heart-line'
                  }`}></i>
                  <span>{likeCount}</span>
                </button>
                
                <div className="flex items-center space-x-2 text-gray-500">
                  <i className="ri-chat-1-line w-5 h-5 flex items-center justify-center"></i>
                  <span>{comments.length}</span>
                </div>
                
                <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-600 transition-colors cursor-pointer">
                  <i className="ri-share-line w-5 h-5 flex items-center justify-center"></i>
                  <span>Share</span>
                </button>
              </div>
              
              <button
                onClick={handleBookmark}
                className={`cursor-pointer transition-colors ${
                  isBookmarked ? 'text-blue-600' : 'text-gray-500 hover:text-blue-600'
                }`}
              >
                <i className={`w-5 h-5 flex items-center justify-center ${
                  isBookmarked ? 'ri-bookmark-fill' : 'ri-bookmark-line'
                }`}></i>
              </button>
            </div>
          </div>
        </article>
        
        <div className="mt-8 bg-white rounded-lg shadow-sm p-8">
          <CommentSection comments={comments} />
        </div>
      </main>
    </div>
  );
}